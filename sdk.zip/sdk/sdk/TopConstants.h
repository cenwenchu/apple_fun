//
//  TopConstants.h
//  sdk
//
//  Created by cenwenchu on 12-6-6.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TopConstants : NSObject

FOUNDATION_EXPORT NSString *const MessageArriveNotification;

@end
