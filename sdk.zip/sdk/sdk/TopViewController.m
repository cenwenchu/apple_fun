//
//  TopViewController.m
//  sdk
//
//  Created by cenwenchu on 12-6-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "TopViewController.h"


@interface TopViewController ()

@end

@implementation TopViewController

@synthesize reqTextField;
@synthesize reqButton;
@synthesize authButton;
@synthesize authWebView;
@synthesize responseContentView;
@synthesize messageAlertLabel;



- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == self.reqTextField) {
        [textField resignFirstResponder];
    }
    return NO;
}

+ (void)cleanForDeallocWebView:(UIWebView *)webView
{
    [webView loadHTMLString:@"" baseURL:nil];
    [webView stopLoading];
    [webView setDelegate:nil];
    [webView removeFromSuperview];
}

- (TopIOSClient*) getInnerClient{
    TopAppDelegate *delegate = (TopAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    return delegate.iosClient;
}

- (IBAction)authReqAction:(id)sender {
    
    //[TopViewController cleanForDeallocWebView:authWebView];
    
    TopIOSClient *iosClient = [self getInnerClient];
        
    [authWebView setDelegate:self];
    
    [iosClient auth:authWebView];
    [self switchView:FALSE];
    
}


- (IBAction)sendRequestAction:(id)sender {
    
    [self switchView:TRUE];
    [responseContentView setText:nil];
    
    NSString *requestStr = reqTextField.text;
    
    if (requestStr && [requestStr length] > 0)
    {
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        
        NSEnumerator *er = [[requestStr componentsSeparatedByString:@"&"] objectEnumerator];
        
        id anObject;
        
        while (anObject = [er nextObject]) {
            
            NSArray *arr = [(NSString *)anObject componentsSeparatedByString:@"="];
            
            if ([arr count] != 2)
            {
                continue;
            }
            
            [params setObject:[arr objectAtIndex:1] forKey:[arr objectAtIndex:0]];
        }
        
        TopIOSClient *iosClient = [self getInnerClient];
        [iosClient api:@"rest" method:@"POST" params:params target:self cb:@selector(showApiResponse:)];
        
    }
    else {
        
        [self message:@"必须填入请求地址."];    
    }
    
}

-(void) message:(NSString *)content
{
    UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Infomation"
                                                      message:content
                                                     delegate:nil
                                            cancelButtonTitle:@"OK"
                                            otherButtonTitles:nil];
    
    [message show];
}
 
-(void)showApiResponse:(NSData *)data
{
    NSLog(@"%@",[NSString stringWithUTF8String:[data bytes]]);
    [responseContentView setText:[NSString stringWithUTF8String:[data bytes]]];
}

-(void)messageNotify:(NSNotification *)paramNotification
{
    NSLog(@"message received");
    NSDictionary *userInfo = [paramNotification userInfo];
    
    id error = [userInfo objectForKey:@"error"];
    
    if (error)
    {
        NSMutableString *errMsg = [[NSMutableString alloc]init];
        [errMsg appendString:@"error code : "];
        [errMsg appendFormat:@"%d",[(NSError *)error code]];
        [messageAlertLabel setText:errMsg];
    }
    {
        [messageAlertLabel setText:@"a new message"];
        [messageAlertLabel setTextColor:[UIColor colorWithRed:0.5f
                                                        green:0.0f blue:0.5f alpha:1.0f]];
        
        [self message:@"you got response from api server"];    
    }
    
}
         

-(void)webViewDidFinishLoad:(UIWebView *)webView
{
    NSString *url = [[[webView request] URL] absoluteString];
    
    NSArray *listItems = [url componentsSeparatedByString:@"#"];
    
    NSEnumerator *enumerator = [listItems objectEnumerator];
    id anObject;
    
    while (anObject = [enumerator nextObject]) {
        
        NSRange range = [(NSString *)anObject rangeOfString:@"access_token="];
        
        if (range.location == NSNotFound)
            continue;
        else {
            NSRange end = [(NSString *)anObject rangeOfString:@"&"];
            NSString *access_token;
            
            if (end.location == NSNotFound)
            {
                access_token = [(NSString *)anObject substringFromIndex:range.location+range.length];
            }
            else {
                access_token = [(NSString *)anObject substringWithRange:NSMakeRange(range.location+range.length,end.location - range.location - range.length)];
            }
            
            
            NSLog(@"%@",access_token);
            NSLog(@"%@",(NSString *)anObject);
            
            TopIOSClient *iosClient = [self getInnerClient];
            
            [iosClient setAccessToken:access_token];
            
            [self switchView:TRUE];
            
            break;
        }
    }
    
    
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.authWebView setHidden:TRUE];
    [self.responseContentView setHidden:FALSE];
    
    // register notification
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(messageNotify:) name:MessageArriveNotification  object:self];    
}

- (void)viewDidUnload
{
    [self setReqTextField:nil];
    [self setReqButton:nil];
    [self setResponseContentView:nil];
    [self setAuthButton:nil];
    [self setAuthWebView:nil];
    [self setMessageAlertLabel:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

- (void)switchView:(BOOL)isAPICall{

    if (isAPICall)
    {
        [self.authWebView setHidden:TRUE];
        
        [self.responseContentView setHidden:FALSE];
    }
    else {
        [self.authWebView setHidden:FALSE];
        
        [self.responseContentView setHidden:TRUE];
    }
}

@end
