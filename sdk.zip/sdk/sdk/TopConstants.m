//
//  TopConstants.m
//  sdk
//
//  Created by cenwenchu on 12-6-6.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "TopConstants.h"

@implementation TopConstants

NSString *const MessageArriveNotification = @"MessageArriveNotification";

@end
